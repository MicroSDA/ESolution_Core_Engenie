<?php
/**
 * User: Ro Kovalenko
 * Date: 12/30/2017
 * Time: 7:59 PM
 */

class Model
{
    public function __construct(){


    }

    public function index(){


    }
}